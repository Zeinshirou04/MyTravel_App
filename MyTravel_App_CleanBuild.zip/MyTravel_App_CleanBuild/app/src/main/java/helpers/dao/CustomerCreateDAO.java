package helpers.dao;

import entities.customer.CustomerData;

public interface CustomerCreateDAO {
    public int create(CustomerData data);
}
