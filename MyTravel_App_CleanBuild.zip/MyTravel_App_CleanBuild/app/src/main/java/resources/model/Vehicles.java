package resources.model;

public class Vehicles {
    protected String table = "vehicles";

    public String getTable() {
        return this.table;
    }
}
