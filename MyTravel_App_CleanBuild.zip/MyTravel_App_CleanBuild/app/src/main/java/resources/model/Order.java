package resources.model;

public class Order {
    protected String table = "order";

    public String getTable() {
        return this.table;
    }
}
