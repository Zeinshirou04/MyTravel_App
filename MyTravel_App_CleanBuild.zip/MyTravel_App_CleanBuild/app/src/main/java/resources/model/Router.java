package resources.model;

public class Router {
    protected String table = "route";

    public String getTable() {
        return this.table;
    }
}
