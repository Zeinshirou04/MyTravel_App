package resources.model;

public class Customer {
    protected String table = "customer";

    public String getTable() {
        return this.table;
    }
}
