package config;

public class FrameConfig extends ThemeConfig {
    public int width = 1280;
    public int height = 720;
}
