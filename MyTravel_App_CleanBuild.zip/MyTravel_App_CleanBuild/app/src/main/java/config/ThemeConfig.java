package config;

import java.awt.Color;

public class ThemeConfig {
    public Color primary = new Color(245,245,245);
    public Color secondary = new Color(103,114,122);
}
